package client;

import java.io.*;
import java.net.*;
 
public class Client {
         
		void Connect(String ipPort) throws IOException{ 
			String toParse = ipPort;
			String delims = "[:]";
			String[] parsed = toParse.split(delims);
	        String hostName = parsed[0];
	        int portNumber = Integer.parseInt(parsed[1]);
	 
	        try (
	            Socket socket = new Socket(hostName, portNumber);
	            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
	            BufferedReader in = new BufferedReader(
	                new InputStreamReader(socket.getInputStream()));
	        ) {
	            BufferedReader stdIn =
	                new BufferedReader(new InputStreamReader(System.in));
	            String fromServer;
	            String fromUser;
	 
	            while ((fromServer = in.readLine()) != null) {
	                System.out.println("Server: " + fromServer);
	                if (fromServer.equals("Bye."))
	                    break;
	                 
	                fromUser = stdIn.readLine();
	                if (fromUser != null) {
	                    System.out.println("Client: " + fromUser);
	                    out.writeUTF(fromUser);
	                    out.flush();
	                }
	            }
	        } catch (UnknownHostException e) {
	            System.err.println("Don't know about host " + hostName);
	            System.exit(1);
	        } catch (IOException e) {
	            System.err.println("Couldn't get I/O for the connection to " +
	                hostName);
	            System.exit(1);
	        }
		}
}
