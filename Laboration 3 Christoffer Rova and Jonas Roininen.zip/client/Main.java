package client;

import client.GUI;
import client.Module;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Module mod = new Module();
		GUI lol = new GUI(mod);
	}
}
